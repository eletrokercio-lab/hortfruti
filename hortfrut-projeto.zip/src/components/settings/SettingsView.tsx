import React, { useState } from 'react';
import {
  Settings,
  RotateCcw,
  ShieldCheck,
  Smartphone,
  Sparkles,
  HelpCircle,
  Database,
  Building,
  CheckCircle2,
  AlertCircle,
  Code,
  Copy,
  ExternalLink,
  GitBranch,
  UploadCloud,
  RefreshCw,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { isSupabaseConfigured, getSupabaseStatus } from '../../lib/supabase';
import { supabaseService } from '../../services/supabaseService';

export const SettingsView: React.FC = () => {
  const { resetToInitialData, userRole, setUserRole, customers, products, orders } = useApp();

  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [syncResult, setSyncResult] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  const supabaseStatus = getSupabaseStatus();

  const handleReset = () => {
    if (
      confirm(
        'Deseja restaurar os dados de demonstração originais? Isso recarregará clientes, produtos, pedidos e dados fiscais de exemplo.'
      )
    ) {
      resetToInitialData();
      alert('Dados restaurados com sucesso!');
    }
  };

  const handleTestSupabase = async () => {
    setIsTesting(true);
    setTestResult(null);
    const res = await supabaseService.testConnection();
    setTestResult(res);
    setIsTesting(false);
  };

  const handleSyncToSupabase = async () => {
    setIsSyncing(true);
    setSyncResult(null);
    const res = await supabaseService.uploadCurrentDataToSupabase({
      customers,
      products,
      orders,
    });
    setSyncResult(res.message);
    setIsSyncing(false);
  };

  const handleCopySqlSchema = () => {
    navigator.clipboard.writeText(`-- O script completo está salvo em /supabase_schema.sql na raiz do projeto.`);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div className="max-w-4xl space-y-6 pb-20">
      <div>
        <h1 className="text-xl font-black text-gray-900 tracking-tight flex items-center gap-2">
          <Settings className="h-6 w-6 text-emerald-600" />
          Configurações, Supabase & GitHub
        </h1>
        <p className="text-xs text-gray-500 mt-0.5">
          Conexão com banco de dados Supabase, repositório GitHub e parâmetros operacionais
        </p>
      </div>

      {/* Supabase Integration Card */}
      <div className="rounded-2xl border border-emerald-200 bg-white p-6 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-600 text-white font-black text-xl shadow-xs">
              <Database className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-gray-900">Banco de Dados Supabase (PostgreSQL)</h2>
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                    supabaseStatus.configured
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {supabaseStatus.configured ? 'Conectado' : 'Aguardando Chaves'}
                </span>
              </div>
              <p className="text-xs text-gray-500">
                Armazenamento relacional em nuvem com alta performance e backups automáticos
              </p>
            </div>
          </div>

          <a
            href="https://supabase.com"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 text-xs font-bold text-emerald-700 hover:text-emerald-800"
          >
            <span>Acessar Supabase</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>

        {/* What is needed from Supabase */}
        <div className="rounded-xl border border-gray-200 bg-gray-50/70 p-4 space-y-3 text-xs">
          <h3 className="font-bold text-gray-900 flex items-center gap-2">
            <span>📋 O que você precisa obter do Supabase:</span>
          </h3>

          <ol className="list-decimal list-inside space-y-2 text-gray-700 pl-1 leading-relaxed">
            <li>
              <strong>Criar um Projeto Gratuito</strong> no site oficial{' '}
              <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-emerald-700 underline font-semibold">
                supabase.com
              </a>.
            </li>
            <li>
              <strong>Executar o Script SQL:</strong> Abra o <em>"SQL Editor"</em> no menu lateral esquerdo do Supabase e cole o conteúdo do arquivo{' '}
              <code className="rounded bg-gray-200 px-1 py-0.5 font-mono text-[11px] text-gray-900">
                /supabase_schema.sql
              </code>{' '}
              (já gerado e pronto na raiz deste projeto). Clique em <strong>Run</strong>.
            </li>
            <li>
              <strong>Copiar as Chaves de Conexão:</strong> No painel do seu projeto Supabase, acesse{' '}
              <strong>Project Settings → API</strong> e copie:
              <div className="mt-2 space-y-1.5 pl-4 font-mono text-[11px]">
                <div className="flex flex-col sm:flex-row sm:items-center gap-1 text-gray-800">
                  <span className="font-bold text-emerald-800 font-sans">1. Project URL:</span>
                  <span className="bg-white border px-2 py-0.5 rounded-sm">VITE_SUPABASE_URL</span>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-1 text-gray-800">
                  <span className="font-bold text-emerald-800 font-sans">2. Project API Keys (anon / public):</span>
                  <span className="bg-white border px-2 py-0.5 rounded-sm">VITE_SUPABASE_ANON_KEY</span>
                </div>
              </div>
            </li>
          </ol>
        </div>

        {/* Actions bar */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleTestSupabase}
            disabled={isTesting}
            className="flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs transition-colors disabled:opacity-50"
          >
            {isTesting ? <RefreshCw className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
            <span>Testar Conexão</span>
          </button>

          <button
            onClick={handleSyncToSupabase}
            disabled={isSyncing || !supabaseStatus.configured}
            className="flex items-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 hover:bg-emerald-100 px-4 py-2.5 text-xs font-bold text-emerald-800 shadow-2xs transition-colors disabled:opacity-40"
          >
            {isSyncing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
            <span>Sincronizar Dados Locais para o Supabase</span>
          </button>

          <a
            href="/supabase_schema.sql"
            download="supabase_schema.sql"
            className="flex items-center gap-1.5 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 px-3.5 py-2.5 text-xs font-semibold text-gray-700 shadow-2xs"
          >
            <Code className="h-4 w-4 text-gray-500" />
            <span>Baixar supabase_schema.sql</span>
          </a>
        </div>

        {testResult && (
          <div
            className={`rounded-xl p-3 text-xs font-semibold border ${
              testResult.success
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-amber-50 text-amber-900 border-amber-200'
            }`}
          >
            {testResult.message}
          </div>
        )}

        {syncResult && (
          <div className="rounded-xl bg-emerald-50 text-emerald-900 border border-emerald-200 p-3 text-xs font-semibold">
            {syncResult}
          </div>
        )}
      </div>

      {/* GitHub Repository Card */}
      <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gray-900 text-white font-black text-xl shadow-xs">
              <GitBranch className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">Integração com GitHub</h2>
              <p className="text-xs text-gray-500">Controle de versão, deploy contínuo e histórico de código</p>
            </div>
          </div>

          <a
            href="https://github.com/new"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 text-xs font-bold text-gray-700 hover:text-gray-900"
          >
            <span>Criar Repositório no GitHub</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>

        <div className="rounded-xl border border-gray-200 bg-gray-50/70 p-4 space-y-3 text-xs">
          <h3 className="font-bold text-gray-900">
            🐙 O que você precisa do GitHub:
          </h3>

          <ol className="list-decimal list-inside space-y-2 text-gray-700 leading-relaxed">
            <li>
              <strong>Conta no GitHub:</strong> Ter uma conta em{' '}
              <a href="https://github.com" target="_blank" rel="noreferrer" className="text-gray-900 underline font-semibold">
                github.com
              </a>.
            </li>
            <li>
              <strong>Criar um Novo Repositório:</strong> Acesse{' '}
              <code className="bg-gray-200 px-1 py-0.5 rounded-sm font-mono text-[11px]">github.com/new</code>, escolha o nome (ex: <code className="bg-gray-200 px-1 py-0.5 rounded-sm font-mono text-[11px]">hortigestao-distribuidora</code>) e marque como <em>Public</em> ou <em>Private</em> (não marque "Initialize with README").
            </li>
            <li>
              <strong>Comandos Git para Enviar o Código:</strong>
              No terminal do seu computador (ou na pasta do projeto), rode:
              <div className="mt-2 rounded-xl bg-gray-900 p-3 font-mono text-xs text-emerald-400 space-y-1 overflow-x-auto shadow-inner">
                <div>git init</div>
                <div>git add .</div>
                <div>git commit -m "feat: Sistema de Gestão HortiGestão v3.0 com Supabase e IA"</div>
                <div>git branch -M main</div>
                <div className="text-amber-300">git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git</div>
                <div className="text-cyan-300">git push -u origin main</div>
              </div>
            </li>
          </ol>
        </div>
      </div>

      {/* Simulator / Role Selector */}
      <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-2xs space-y-3">
        <h3 className="text-sm font-bold text-gray-900">Perfil de Acesso do Sistema</h3>
        <p className="text-xs text-gray-500">
          Você pode alternar o perfil para testar a experiência específica de cada operador:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          <button
            onClick={() => setUserRole('admin')}
            className={`p-3 rounded-xl border text-left text-xs transition-all ${
              userRole === 'admin'
                ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-600/20 font-bold'
                : 'border-gray-200 bg-white hover:bg-gray-50 text-gray-700'
            }`}
          >
            <span className="block font-bold">1. Proprietário</span>
            <span className="text-[11px] text-gray-500 font-normal">Acesso total e relatórios</span>
          </button>

          <button
            onClick={() => setUserRole('operator')}
            className={`p-3 rounded-xl border text-left text-xs transition-all ${
              userRole === 'operator'
                ? 'border-blue-600 bg-blue-50 text-blue-900 ring-2 ring-blue-600/20 font-bold'
                : 'border-gray-200 bg-white hover:bg-gray-50 text-gray-700'
            }`}
          >
            <span className="block font-bold">2. Operador</span>
            <span className="text-[11px] text-gray-500 font-normal">Pedidos e necessidades</span>
          </button>

          <button
            onClick={() => setUserRole('driver')}
            className={`p-3 rounded-xl border text-left text-xs transition-all ${
              userRole === 'driver'
                ? 'border-amber-600 bg-amber-50 text-amber-900 ring-2 ring-amber-600/20 font-bold'
                : 'border-gray-200 bg-white hover:bg-gray-50 text-gray-700'
            }`}
          >
            <span className="block font-bold">3. Motorista</span>
            <span className="text-[11px] text-gray-500 font-normal">Foco mobile & pesagem</span>
          </button>

          <button
            onClick={() => setUserRole('accountant')}
            className={`p-3 rounded-xl border text-left text-xs transition-all ${
              userRole === 'accountant'
                ? 'border-purple-600 bg-purple-50 text-purple-900 ring-2 ring-purple-600/20 font-bold'
                : 'border-gray-200 bg-white hover:bg-gray-50 text-gray-700'
            }`}
          >
            <span className="block font-bold">4. Contador</span>
            <span className="text-[11px] text-gray-500 font-normal">Fechamento fiscal</span>
          </button>
        </div>
      </div>

      {/* Reset Data */}
      <div className="rounded-2xl border border-rose-200 bg-rose-50/50 p-5 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-rose-900">Restaurar Dados de Demonstração</h3>
          <p className="text-xs text-rose-700 mt-0.5">
            Volta o sistema para o conjunto inicial oficial de produtos, clientes de exemplo, pedidos e faturas.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center justify-center gap-2 rounded-xl bg-rose-600 hover:bg-rose-700 px-4 py-2.5 text-xs font-bold text-white shadow-xs shrink-0"
        >
          <RotateCcw className="h-4 w-4" />
          <span>Restaurar Padrão</span>
        </button>
      </div>
    </div>
  );
};
