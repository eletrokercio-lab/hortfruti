import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { Customer, Product, Order, Delivery, AccountsReceivable } from '../types';

export const supabaseService = {
  isAvailable: () => isSupabaseConfigured() && supabase !== null,

  // Test connection to Supabase
  testConnection: async (): Promise<{ success: boolean; message: string }> => {
    if (!isSupabaseConfigured() || !supabase) {
      return {
        success: false,
        message: 'Variáveis VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY não configuradas.',
      };
    }

    try {
      const { error } = await supabase.from('products').select('count', { count: 'exact', head: true });
      if (error) {
        return {
          success: false,
          message: `Erro ao consultar Supabase: ${error.message} (Verifique se executou o script supabase_schema.sql no SQL Editor).`,
        };
      }
      return {
        success: true,
        message: 'Conexão com o Supabase estabelecida com sucesso!',
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Falha de conexão: ${err.message}`,
      };
    }
  },

  // Upload current local state to Supabase
  uploadCurrentDataToSupabase: async (data: {
    customers: Customer[];
    products: Product[];
    orders: Order[];
  }): Promise<{ success: boolean; message: string }> => {
    if (!isSupabaseConfigured() || !supabase) {
      return { success: false, message: 'Supabase não configurado.' };
    }

    try {
      // 1. Upload Customers
      if (data.customers.length > 0) {
        const mappedCustomers = data.customers.map((c) => ({
          id: c.id,
          name: c.name,
          trade_name: c.tradeName || null,
          document: c.document,
          phone: c.phone,
          whatsapp: c.whatsapp,
          street: c.address.street,
          number: c.address.number,
          neighborhood: c.address.neighborhood,
          city: c.address.city,
          state: c.address.state,
          zip_code: c.address.zipCode,
          reference: c.address.reference || null,
          status: c.status,
          payment_method: c.paymentMethod,
          payment_term: c.paymentTerm,
          credit_limit: c.creditLimit,
          commercial_condition: c.commercialCondition,
          notes: c.notes || null,
        }));

        const { error: custErr } = await supabase.from('customers').upsert(mappedCustomers);
        if (custErr) throw new Error(`Erro em clientes: ${custErr.message}`);
      }

      // 2. Upload Products
      if (data.products.length > 0) {
        const mappedProducts = data.products.map((p) => ({
          id: p.id,
          name: p.name,
          category: p.category,
          unit: p.unit,
          sales_type: p.salesType,
          default_price: p.defaultPrice,
          avg_cost: p.avgCost,
          origin: p.origin,
          notes: p.notes || null,
          status: p.status,
        }));

        const { error: prodErr } = await supabase.from('products').upsert(mappedProducts);
        if (prodErr) throw new Error(`Erro em produtos: ${prodErr.message}`);
      }

      return {
        success: true,
        message: 'Dados sincronizados com o banco de dados Supabase com sucesso!',
      };
    } catch (err: any) {
      return {
        success: false,
        message: err.message,
      };
    }
  },
};
